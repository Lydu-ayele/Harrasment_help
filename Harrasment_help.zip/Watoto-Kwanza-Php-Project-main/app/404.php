<!DOCTYPE html>
<html lang="en" class="body-full-height">
<head>

 <title> Page not  found | SpeakUp</title>
 
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=Edge">
 <meta name="description" content="">
 <meta name="keywords" content="">
 <meta name="author" content="">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


 <link rel="stylesheet" href="../css/bootstrap.min.css">
 <link rel="stylesheet" href="../css/font-awesome.min.css">
 <link href="../css/bootstrap-sidebar.min.css" rel="stylesheet">
 <link href="../css/app.css" rel="stylesheet">

 <!-- MAIN CSS -->
 <link href="../css/app.css" rel="stylesheet">

</head>

<body>


  <div class="notfound-container">

    <div class="box container">
      <h1>Page Not Found</h1>
      <p>Oop's!<br>
      This page is either under construction or does not exist</p>
      <a href="../" class="btn btn-light">Go to homepage</a>
    </div>

  </div>

</body>

</html>